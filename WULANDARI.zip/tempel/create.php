<?php
include 'functions.php';
$pdo = pdo_connect_mysql();
$msg = '';

if (!empty($_POST)) {

    $id = isset($_POST['id']) && !empty($_POST['id']) && $_POST['id'] != 'auto' ? $_POST['id'] : NULL;

    $nama = isset($_POST['nama']) ? $_POST['nama'] : '';
    $email = isset($_POST['email']) ? $_POST['email'] : '';
    $telp = isset($_POST['telp']) ? $_POST['telp'] : '';
    $alamat = isset($_POST['alamat']) ? $_POST['alamat'] : '';


    $stmt = $pdo->prepare('INSERT INTO kontak VALUES (?, ?, ?, ?, ?)');
    $stmt->execute([$id, $nama, $email, $telp, $alamat]);

    $msg = 'Sukses Membuat !!!';
}
?>


<?= template_header('Create') ?>

<div class="content update">
    <h2>Buat Kontak</h2>
    <form action="create.php" method="post">
        <label for="id">ID</label>
        <label for="nama">Nama</label>
        <input type="text" name="id" value="auto" id="id">
        <input type="text" name="nama" id="nama">
        <label for="email">Email</label>
        <label for="telp">No. Telp</label>
        <input type="text" name="email" id="email">
        <input type="text" name="telp" id="telp">
        <label for="alamat">alamat</label>
        <input type="text" name="alamat" id="alamat">
        <input type="submit" value="Create">
    </form>
    <?php if ($msg) : ?>
        <p><?= $msg ?></p>
    <?php endif; ?>
</div>

<?= template_footer() ?>